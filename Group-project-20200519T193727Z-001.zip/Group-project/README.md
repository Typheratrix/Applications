***Name of the project: Budget Calculator.

***Name of the team: Gold Team (group 9)

***Full name of team members: Vi Vu, James Logan, Gabriel Kao, Benjamin Parish, Richard Escalona.

***Short Description: This is the Golden Team application. We are making a Budget Calculator. This application allow you to sign up and sign in. You can update your spending and view the pie charts that demonstrate your spending in a week, a month, 3 months, 6 months, 1 year.

***Login Info: username: abc123 password: abc123 (You can Sign Up your own account if you want to)

***Versions and other requirements: Java (above 8), Scene Builder (above 2), JavaFX (version 13.0.1)
